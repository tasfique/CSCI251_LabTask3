//Name- Tasfique Enam
//Student ID- 5886429
//LabTask3 Q1

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

int numberOfEmp;
string fileName;
double total;

struct Info {
    int empNum;
    string name;
    double sales;
};

double calculation(Info info[]) {
    double sum = 0.0;
    for(int i=0; i<numberOfEmp; i++) {
        sum += info[i].sales;
    }
    return sum;
}

double display (Info info [] ) {
    double total = calculation(info);
    for(int i=0; i<numberOfEmp; i++)
    {
        cout <<"\nTotal sales made by Employee Number "<< info[i].empNum <<" is " << info[i].sales << endl;

    }
    cout << "\nThe total sales are " <<total;
}

int main () {
    cout << "Enter the name of the New TXT file " << endl;
    cin >> fileName;
    fileName=fileName+".txt";


    cout << "Enter How many Employess are there? " << endl;
    cin >> numberOfEmp;

    while(numberOfEmp <0) {
        cout << "Input error " << endl;
        cout << "Enter How many Employess are there? " << endl;
        cin >> numberOfEmp;
    }

    Info info[numberOfEmp];

    fstream ifs;
    ifs.open(fileName.c_str(),ios::out);

    for(int i=0; i<numberOfEmp; i++) {
        cout << "Enter the Employee Number" << endl;
        cin >> info[i].empNum;
        while(info[i].empNum < 0) {
            cout << "Input error " << endl;
            cout << "Enter the Employee Number" << endl;
            cin >> info[i].empNum;
        }
        cout << "Enter the Name of the Employee " << endl;
        cin >> info[i].name;

        cout << "The Sales made by this Employee " << endl;
        cin >> info[i].sales;
        while(info[i].sales < 0) {
            cout << "Input error " << endl;
            cout << "The Sales made by this Employee " << endl;
            cin >> info[i].sales;
        }

        ifs << info[i].empNum << endl;
        ifs << info[i].name << endl;
        ifs << info[i].sales << endl;
    }

    ifs.close();


    ifs.open(fileName.c_str(), ios::in);

    if(!ifs)
        cout << "File could not be openend. " << endl;
    else {
        double salesArray [numberOfEmp];
        for(int i=0; i<numberOfEmp; i++) {
            //while(!ifs.eof())
            int en;
            string nm;
            double sal;
            ifs>>en>>nm>>sal;
            info[i].empNum=en;
            info[i].name=nm;
            info[i].sales=sal;

            cout<<"Emp Num "<<en<<endl;
            cout<<"Emp Name "<<nm<<endl;
            cout<<"Sales "<<sal<<endl;

            //salesArray [i] = {sal};

        }
        ifs.close();

        double displayInfo = display(info);

    }


    return 0;
}



